# JUSTICE-AI Frontend Prototype

Open `index.html` in a browser.

Pages:
- index.html — AI Chat
- new-case.html — New Case / AI Guided Interview
- cases.html — My Cases
- upload.html — Upload Documents
- research.html — Legal Research
- timeline.html — Evidence Timeline
- legal-aid.html — Find Legal Aid
- resources.html — Resources
- assistant.html — AI Assistant
- missing-evidence.html — Missing Evidence Check
- document-analysis.html — Document Analysis
- citation.html — Citation Verification
- settings.html — Settings

All pages share `style.css` and the same dark purple/glow visual language.
This is a frontend prototype; backend/API/database actions are placeholders.
